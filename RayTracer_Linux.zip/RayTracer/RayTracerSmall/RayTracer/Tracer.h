#pragma once
#ifndef TRACER_H
#define TRACER_H

#include <stdlib.h>
#include <cstdio>
#include <cmath>
#include <fstream>
#include <vector>
#include <iostream>
#include <cassert>

#include <chrono>
#include "Sphere.h"

//[comment]
// This variable controls the maximum recursion depth
//[/comment]
#define MAX_RAY_DEPTH 5

typedef void * (*ThreadFunction)(void *);

class Tracer
{
public:
	void BasicRender();
	void SimpleShrinking(bool bUseThreading = false);
	void SmoothScaling(int iCount);

private:
	Vec3f trace(
		const Vec3f& rayorig,
		const Vec3f& raydir,
		const std::vector<Sphere>& spheres,
		const int& depth
	);
	void render(const std::vector<Sphere>& spheres, int iteration);
	void *Render(void * settings);
	inline float mix(const float& a, const float& b, const float& mix) { return b * mix + a * (1 - mix); }

	struct TracerSettings
	{
		std::vector<Sphere> spheres;
		int iteration;
	};
	
};

#endif // !TRACER_H